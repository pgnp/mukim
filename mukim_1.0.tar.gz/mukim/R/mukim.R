mukim <-
function(nadata, indep=id(nadata)$ind, depend=id(nadata)$dep, b=2, ordprop=1, knm=c(10,100,1), kernelDist=1, kernelProb=1, maxProb=0.99, minDon=2,robVar=1, lagrProb=1, minShare=0.2, boundOrient=1/24, boundShrink=5/6, cores=1) {
  mukimp <- function(nadata, indeps=indep, depends=depend, m=b, ordprop, kh1=kh, kernelDist, kernelProb, maxProb, minDon, robVar, lagrProb, minShare, boundOrient, boundShrink) {
    mindet <- 10^-6 # Minimum value of determinant before at the boundary.
    alldata <- list()
    for (k in 1:m) { # Loop over imputation sets(b) - if possible put this on different kernels
      impdata <- as.matrix(nadata) # The imputed dataset
      dondon <- allunits(ind=indeps,dep=depends,impdata) # calculate all donors and donees
      for (ii in which(lapply(dondon$donee,function(x) length(x)>0)==TRUE)) { # loop over blocks of imputation which are not empty
        propdist <- propensityScore(impdata,ordprop,dondon,ii) # calculate predictive mean match
        randii <- sample(1:length(dondon$donee[[ii]])) # randomized order of imputation in current block
        narows <- dondon$donee[[ii]][randii] # which rows to use as donees in current block
        obsrows <- dondon$donor[[ii]] # which rows to start using as donors in current block
        ccn <- length(obsrows) # nr of initial donors
        ccm <- length(dondon$ind2[[ii]]) # nr of donor variables
        wimpdata <- whitening(impdata[c(obsrows,narows),dondon$ind2[[ii]]],ccm) # whitened data
        for (i in 1:length(narows)) { # Loop over rows that have missing values
          if (ordprop==1) { ccimpdata <- as.matrix(wimpdata[1:ccn,]) } # donor x-data
          improw <- wimpdata[ccn+1,] # Observed ind values on row to impute
          ccdistvar <- ccvar(ccimpdata,ccm,robVar,kernelDist) # calculate (robust) covariance matrix
          mhdist <- maha(ccimpdata,improw,ccdistvar) # Distance between ccimpdata and improw.
          distord <- order(mhdist) # order of mhdist
          donor <- donors(kh1,ccn,ccm,minDon,distord,mhdist,ccimpdata) # use function to get out the four below
          donProb <- donorProb(donord=donor$donord,h=donor$h,ccm,maxProb,kernelProb) # Calculate donProb using donorProb function.
          if(sum(donor$donord)>0) { # if all potential donors are exact matches, go directly to sampling the donor
            if (boundOrient>0 | boundShrink<1) {  # If shrinkage or reorientation at boundary is used (1) or not (else)
              boundary <- funb(donorname=donor$donorname,donord=donor$donord,ccimpdata,improw,ccn,minShare) # Test if on boundary.
              if (boundary==0 & lagrProb==1) { # If not on boundary, but lagrangean
                lagr <- funlagr(ccimpdata,donor$donord,impdata,i,ordprop,propdist,donProb,mindet,maxProb,donor$donorname,improw,boundary)
                boundary <- lagr$boundary; donProb <- lagr$donProb #Apply Lagrangean
                if (boundary==0) { # If not on boundary after lagrangean
                  donProb <- donProbFinal(lagr$tempw,lagr$Ww) # Set donProb to temporary donProb.
                } # End
              } # End of not on boundary
              if (boundary==1) { # If on boundary, shrink volume and/or change orientation by changing cov. matrix.
                ishrink <- donor$constVarLength # This is to count the number of times the vector is shrunk
                while (ishrink<ccm) { # While loop for shrinking volume.
                  ishrink <- ishrink+1 # Volume is shrunk once more
                  if (ccm>(1+donor$constVarLength)) { #only if dim(X-variables)>1
                    ccdistvar[donor$constVar,donor$constVar] <- poolOrient(donor$donorname,donor$donord,ccm-donor$constVarLength,ccn,ccimpdata[,donor$constVar],improw[donor$constVar],boundOrient,ccdistvar[donor$constVar,donor$constVar]) #reorient distance cov-matrix
                  }
                  ifelse (max(ccdistvar)>500, mhdist <- mahalanobis(ccimpdata,improw,ginv(ccdistvar),inverted=TRUE),{ # Recalculate distance between ccimpdata and improw.           # Recalculate distances, donors, and donProbs using new ccdistvar.
                    mhdist <- maha(ccimpdata,improw,ccdistvar) }
                  ) # Recalculate distance between ccimpdata and improw.
                  donor <- donors(kh1+ishrink/ccm*(boundShrink-1),ccn,ccm,minDon,distord,mhdist,ccimpdata) # new values based on shrinkage
                  #if (length(donor$donord)<minDon) { donord <- sort(mhdist)[1:min(ccn,minDon)] } # Ensure there are at least minDon donors in donord.
                  donProb <- donorProb(donord=donor$donord,h=donor$h,ccm,maxProb,kernelProb) # Use donorProb function.
                  if (lagrProb==1) { lagr <- funlagr(ccimpdata,donor$donord,impdata,i,ordprop,propdist,donProb,mindet,maxProb,donor$donorname,improw,boundary)
                                     boundary <- lagr$boundary; donProb <- lagr$donProb } #Apply Lagrangean
                }
              } # End of shrink-loop and boundary.
            } else { ## THIS IS IF SELECTED NOT TO USE SHRINKAGE AT THE BOUNDARY
              boundary <- 0
              if (lagrProb==1) { lagr <- funlagr(ccimpdata,donor$donord,impdata,i,ordprop,propdist,donProb,mindet,maxProb,donor$donorname,improw,boundary)
                                 boundary <- lagr$boundary; donProb <- lagr$donProb } #Apply Lagrangean
            } # END OF CONB
            if (lagrProb==1 & boundary==1) {
              if (lagr$tempd[lagr$i2]>=mindet) { # If determinant>=mindet~=0, set donProbs to recalculated donProbs in tempw.     ### If on boundary but lagrangean unbiased solution found, set donProbs to recalculated donProbs from tempw
                donProb <- donProbFinal(lagr$tempw,lagr$Ww) # Set donProb to temporary donProb.
              }
            } # end
            donProb[donProb<0] <- 0 # Ensure no small negative donProbs
          } #
          sampledonord <- sample(donor$donorname,1,prob=donProb) # Sample a donor row to be imputed
          impdata[narows[i],dondon$dep2[[ii]]] <- impdata[obsrows[sampledonord],dondon$dep2[[ii]]] # Impute missing values from the sampled donor row
          obsrows <- c(obsrows,narows[i]) # Add the imputed row to the observed potential donors
          ccn <- ccn+1 # add another row
          } # Loop over narows (i in narows)
      } # Loop of blocks (in dondon)
      alldata[[k]] <- impdata
    } # Loop over imputation sets
    alldata
  } #end mukimp
  whitening <- function(cimpdata,ccm) { # whitening of data
    if(ccm==1) {
      as.matrix((cimpdata-mean(cimpdata))/sd(cimpdata))
    } else {
      crossprod(t(cimpdata)-colMeans(cimpdata),t(chol(solve(var(cimpdata)))))
    }
  }
  donProbFinal <- function(tempw,Ww) { #function to finalize donProb
    tempw[as.numeric(names(Ww))] <- Ww # Finalize temporary donProbs.
    #  names(tempw) <- names(donProb) # Set names to temporary donProbs.
    donProb <- tempw # Set donProb to temporary donProb.  
    donProb
  } #end donProbFinal
  allunits <- function(ind,dep,nadata) { # function to decide order of imputation
    inddep <- function(ind,dep,nadata) { # need to add accurate defaults  #
      ind2 <- list() #indepents in order of imputation
      dep2 <- list() #dependents in order of imputation
      check2 <- list()
      for (i in 1:length(dep)) {
        if (length(dep[[i]])==1) {
          dep2 <- append(dep2,list(dep[[i]]))
          ind2 <- append(ind2,list(ind[[i]])) 
          check2 <- append(check2,list(dep[[i]]))
        } 
        else {
          temp <- t(combos(length(dep[[i]]))$binary)*dep[[i]]
          for (j in 1:ncol(temp)) { 
            ind2 <- append(ind2,list(ind[[i]]))
            dep2 <- append(dep2,list(temp[temp[,j]>0,j])) 
            check2 <- append(check2,list(dep[[i]]))
          }
        }
      }  
      if (sum(unlist(mapply(function(x,y) intersect(x,y),x=ind2,y=dep2)))>0){
        stop("Same donor and donee variables in at least one block")
      }
      list(ind2 = ind2,dep2 = dep2,check2 = check2)
    }
    ind2 <- inddep(ind,dep,nadata)$ind2
    dep2 <- inddep(ind,dep,nadata)$dep2  
    indep3 <- inddep(ind,dep,nadata)$check2
    ind3 <- list() # donors
    dep3 <- list() # donees
    mdata2 <- is.na(nadata)*1
    for (i in 1:length(ind2)) {
      ind3[[i]] <- which(apply(mdata2[,c(ind2[[i]],dep2[[i]])]==0,1,all)) # find the donors
      dep3[[i]] <- which(apply(cbind(mdata2[,ind2[[i]]]==0,mdata2[,dep2[[i]]]==1,mdata2[,setdiff(indep3[[i]],dep2[[i]])]==0),1,all) ) # find the donees
      mdata2[dep3[[i]],dep2[[i]]] <- 0
    }
    if (is.integer(which(mdata2==1,arr.ind=T))==F) {
      stop("At least one donee has no donors!")
    }
    list(donor=ind3,donee=dep3,ind2=ind2,dep2=dep2) # which values are missing after imputation?
  }
  ccvar <- function(ccimpdata,ccm,robVar,kernelDist) { #function to calculate (robust) covariance matrix of complete cases
    if (robVar==1) { ccdistvar <- var(ccimpdata) } else
#    if (robVar==2) { ccdistvar <- cov.rob(ccimpdata, quantile.used=20)$cov } else
    if (robVar==2) { ccdistvar <- cov.rob(ccimpdata)$cov } else
    if (robVar==3) { ccdistvar <- cov.mve(ccimpdata)$cov } else
    if (robVar==4) { ccdistvar <- cov.mcd(ccimpdata)$cov } else
    if (robVar==5 & ccm==1) { ccdistvar <- min(var(ccimpdata),((quantile(ccimpdata)[4]-quantile(ccimpdata)[2])/1.34)^2) } else
    if (robVar==5 & ccm>1) { ccdistvar <- cov.nnve(ccimpdata)$cov }
    if (kernelDist==2 & ccm>1) { ccd <- matrix(0,dim(ccdistvar)[1],dim(ccdistvar)[2]); diag(ccd) <- diag(ccdistvar); ccdistvar <- ccd } # If Sq Euclid distance, calculate variances.
#    diag(ccdistvar)[diag(ccdistvar)==0] <- 10^10
  ccdistvar
  }
  donorProb <- function(donord,h,ccm,maxProb,kernelProb) { #2 Function to calculate donor probabilities using different kernels (y)
    if (kernelProb==1) { donProb <- gamma(ccm/2)*ccm*(ccm+2)*(1-donord/h^2)/4/pi^(ccm/2)  # Epanechnikov kernel, Silverman p76.
                         if (sum(donProb)==0) { donProb <- rep(1/length(donord),length(donord)) } # If all donProb zero, set to uniform.
                         donProb <- donProb/sum(donProb) }  # Standardize donProbs so that they sum to 1.
    if (kernelProb==2|kernelProb==3) { donProb <- rep(1/length(donord),length(donord)) } # Uniform kernel
    while(length(donProb[donProb>maxProb])>0) { # Ensure no donProbs are larger than maxdonProb (maxProb)
      donProb[donProb>=maxProb] <- maxProb # Set donProbs larger than max donProb to max donProb (maxProb)
      maxProbi <- (1-sum(donProb[donProb>=maxProb]))/sum(donProb[donProb<maxProb]) # Constant which to increase donProbs<maxdonProb with.
      donProb[donProb<maxProb] <- donProb[donProb<maxProb]*maxProbi # Recalculate donProbs for donor rows so they don�t exceed maxProb.
      donProb[is.nan(donProb)] <- (1-sum(donProb[!is.nan(donProb)]))/length(donProb[is.nan(donProb)]) } # If maxProbi==inf, so sum(donProb)<1, set NaN to 1-sum(donProb)/#NaN
    donProb
  }
  funb <- function(donorname=donor$donorname,donord=donor$donord,ccimpdata,improw,ccn,minShare) { # Function to find if on boundary or not
    hccimpdata <- ccimpdata[donorname,] # Take rows from ccimpdata with rownames in donord and put in hccimpdata
    ifelse(length(improw)==1, { # This is the calculation of the normal vector from improw to mean of hccimpdata
      boundaryshare <- (length(ccimpdata[ccimpdata>improw])+0.5*length(ccimpdata[ccimpdata==improw]))/ccn },{ # Calculate ratio of values above or below improw
        normal <- as.numeric(colMeans(t(t(hccimpdata)-improw)/donord^.5))  # sweep verkar l�ngsammare ... microbenchmark(as.numeric(colMeans(t(t(hccimpdata)-improw)/donord^.5)),colMeans(sweep(hccimpdata,2,improw)/donord^.5),times=1000)
        normeq <- colSums((t(hccimpdata)-improw)*normal) # This is the value of the normal equation
        boundaryshare <- (length(normeq[normeq>0])+0.5*length(normeq[normeq=0]))/length(normeq) }) # Calculate ratio of values above or below the normal equation
    ifelse(boundaryshare<minShare | boundaryshare>(1-minShare), boundary <- 1, boundary <- 0)
    boundary
  }
  poolOrient  <- function(donorname,donord,ccm,ccn,ccimpdata,improw,boundOrient,ccdistvar) { # Function to shrink pool
    bmatrix <- diag(ccm) # Define bmatrix as unit matrix
    bmatrix[,1] <- as.numeric(colMeans(t(t(ccimpdata[donorname,][donord>0,])-(as.vector(improw)))/donord[donord>0]^.5)) # First vector is set to normalvector.
    bmatrix <- qr.Q(qr(bmatrix)) # Solve for Q in QR-decomposition. Need to add check whether bmatrix is singular? If, change vector that is equal to the normal.
    bmatrix[,1] <- bmatrix[,1]*ccn^(-boundOrient) # Adjust first vector for h
    bmatrix[,2:ccm] <- bmatrix[,2:ccm]*ccn^(boundOrient/(ccm-1)) # Adj. vectors so that vol. is decr. max. ccm times (where vol=h)
    ccdistvar <- t(bmatrix)%*%ccdistvar%*%bmatrix
    ccdistvar
  }
  donors <- function(kh,ccn,ccm,minDon,distord,mhdist,ccimpdata) {   #donors function
    nrdon <- function(kh,ccn,ccm,minDon,mhdist) {   #4 number of donors function
      nrdonors <- min(ccn,kh*ccn^((4/(4+ccm)))) # Proportionality constant for variable bandwidth, see Silverman p99.
      if (nrdonors<minDon) nrdonors <- min(ccn,minDon)
      max(round(nrdonors),length(mhdist[mhdist==min(mhdist)])) # if closest potential donors have same distance, use them all
    }
    nrdonors <- nrdon(kh,ccn,ccm,minDon,mhdist) # number of donors
    donorname <- distord[1:(nrdonors+1)] # rownumbers of donors+1, to get correct h, later +1 removed
    donord <- mhdist[donorname]
    h <- mean(donord[nrdonors:(nrdonors+1)])^.5 # Set h according to what k is.
    donorname <- donorname[1:nrdonors]
    constVar <- which(diag(var(ccimpdata[donorname,]))==0) # which variables in donorpool are constant
    constVarLength <- length(constVar) # nr of constant variables in donorpool
    list(nrdonors=nrdonors,donorname=donorname,donord=donord[1:nrdonors],h=h,constVar=setdiff(1:ccm,constVar),constVarLength=constVarLength)
  }
  funlagr <- function(ccimpdata,donord,impdata,i,ordprop,propdist,donProb,mindet,maxProb,donorname,improw,boundary) { #Function to apply the lagrangean to the donProbs
    donvalue <- ccimpdata[donorname,]  # Values from donor variables. This is used for checking unbiasedness of donors.
    if (ordprop==1) { distance <- t(t(donvalue)-improw ) } # Calculate donor variables distances from improw.
    if (ordprop==2|ordprop==3|ordprop==4) { distance <- t(t(donvalue)-(propdist[i])) } # Calculate donor variables distances from improw.
    #Set up matrix to solve for donProbs under constraints of unbiasedness and donProb constraint: 0<=donProb<=maxProb
    d1 <- dim(distance)[1] # Distance dimension 1. ## Skulle kunna �ndra d1 och d2 till length(donord) och ccm??
    d2 <- dim(distance)[2] # Distance dimension 2. ## Skulle kunna �ndra d1 och d2 till length(donord) och ccm??
    wid <- 1:(d1+d2+1) # Id of rows and columns in matrix and values in vector.
    D11 <- diag(d1); D12 <- (-1/2)*cbind(distance,1); D1 <- cbind(D11,D12) # First row-block of matrix.
    D21 <- t(distance); D22 <- matrix(0,d2,d2+1); D2 <- cbind(D21,D22) # Second row-block of matrix.
    D31 <- rep(1,d1); D32 <- rep(0,d2+1); D3 <- c(D31,D32) # Third row-block of matrix.
    Dd <- rbind(D1,D2,D3) # Create matrix.
    rownames(Dd) <- 1:(d1+d2+1); colnames(Dd) <- 1:(d1+d2+1) # Set names to matrix.
    Dd2 <- Dd # Create copy of matrix.
    tempw <- rep(0,d1) # This is where temporary donProbs for id:s not fulfilling the donProb constraint are stored.
    colw <- c(donProb,rep(0,d2),1) # Create column vector for solving donProbs.
    names(colw) <- 1:(d1+d2+1) # Set names to column vector for solving donProbs.
    colw2 <- colw # Create copy of column vector for solving donProbs.
    # While-loop to make sure that constraints are fulfilled.
    tempd <- det(Dd2) # Save initial determinant in tempd.
    i1 <- 1 # Value for keeping while-loop alive
    if (tempd<mindet) {  # If initial solution is singular, do not start while loop.
      i1 <- 0; boundary <- 1; Ww <- donProb; tempw <- donProb # keep old donProbs
    } # End of if initial solution is singular
    i2 <- 1 # Value for counting determinants
    while (i1==1) { # While-loop for solving new donProbs, where id:s not fulfilling constraints are excluded.
      Ww <- solve(Dd2,colw2)[1:(length(colw2)-d2-1)] # Solve for new donProbs, where id:s not fulfilling constraints are excluded.
      if (sum(Ww*(Ww<0))<0) { # Test whether any donProb<0.
        wlow <- Ww<0 # TRUE if donProb<0.
        wid <- c(wid[1:length(wlow)][!wlow],wid[(length(wlow)+1):length(colw2)]) # Decrease wid with wlow==TRUE.
        Dd2 <- Dd[wid,wid] # Matrix reduced with wlow==TRUE.
        colw2 <- colw[wid] 
      } # Column vector reduced with wlow==TRUE.
      if (sum(Ww*(Ww<0))==0 & max(Ww)>maxProb) { # Test whether any donProb>maxProb.
        whigh <- -(1:length(Ww))*Ww*(Ww==max(Ww))==min(-(1:length(Ww))*Ww*(Ww==max(Ww))) # Set whigh==TRUE for donProb>maxProb (the last value if more than one).
        wid <- c(wid[1:length(whigh)][!whigh],wid[(length(whigh)+1):length(colw2)]) # Take away value for which whigh==TRUE from wid.
        Dd2 <- Dd[wid,wid] # Matrix reduced with whigh==TRUE.
        colw2 <- colw[wid] # Column vector reduced with whigh==TRUE.
        tempw[as.numeric(names(Ww[whigh]))] <- maxProb # tempw is set to maxProb for whigh==TRUE.
        colw2[length(colw2)] <- colw2[length(colw2)] - maxProb  # 'Sum of donProbs' constraint is decreased with maxProb.
      } # End of checking donProb constraints.
      i2 <- i2+1 # Add nr to value for counting determinants.
      tempd[i2] <- det(Dd2)  # Save determinant in tempd.
      if (tempd[i2]<mindet) { i1 <- 0; boundary <- 1 } # If determinant<mindet then stop while-loop and at boundary.
      if (sum(Ww*(Ww<0))==0 & max(Ww)<=maxProb) { i1 <- 0 } # If donProb constraint fulfilled then stop while-loop.
    } # End of while-loop
    if (boundary==0) { ## If not on boundary after linear restriction, set donProbs to recalculated donProbs in tempw.
      tempw[as.numeric(names(Ww))] <- Ww # Finalize temporary donProbs.
      names(tempw) <- names(donProb) # Set names to temporary donProbs.
      donProb <- tempw
    } # Set donProb to temporary donProb.
    list(boundary=boundary,donProb=donProb,tempw=tempw,Ww=Ww,tempd=tempd,i2=i2)
  } # End of funlagr
  propensityScore <- function(impdata,ordprop,dondon,ii) { # if necessary, create propensity distances
    if (ordprop==1) { propdist <- NULL }
    if (ordprop==2) { propdist <- glm(family=binomial, impdata[,dondon$dep2[[ii]]] ~ impdata[,dondon$ind2[[ii]]])$fitted }    
    propdist
  }
###Start of actual function
  knm[1]/knm[2]^(4/(4+knm[3])) -> kh # factor to control number of donors
  if (kernelProb==2) kh <- kh*((25*(3/5)^(knm[3]))/(9*(1/2)^(knm[3])))^(1/(knm[3]+4)) # Uniform canonical to Epanechnikov
  if (maxProb<1/minDon) maxProb <- 1/minDon # Ensure max donProb >=1/minDon
  if (minDon<2) minDon <- 2 # Ensure at least 2 donors
  if (boundOrient<0) boundOrient <- 0 # Ensure orientation
  if (boundShrink>1) boundShrink <- 1 # Ensure shrinkage
  if(cores>1) {
    lapply(list('doParallel', 'doRNG'), require, character.only = TRUE)
    if(detectCores()>1) {
      cl <- makeCluster(min(cores,detectCores())) #setup parallel backend to use more processors
      registerDoParallel(cl)
      clusterExport(cl, c("nadata","indep","depend"), envir=environment())
      imp <- foreach(n=1:b, .combine=c, .packages=c("mvnfast","covRobust","MASS","hier.part")) %dorng% {
        mukimp(nadata,indeps=indep,depends=depend,m=1,ordprop,kh,kernelDist,kernelProb,maxProb,minDon,robVar,lagrProb, minShare,boundOrient,boundShrink)
      }
      stopCluster(cl)
      imp
    }
  } else {
    lapply(list('covRobust', 'MASS', 'mvnfast','hier.part'), require, character.only = TRUE)
    mukimp(nadata,indeps=indep,depends=depend,m=b,ordprop,kh,kernelDist,kernelProb,maxProb,minDon,robVar,lagrProb, minShare,boundOrient,boundShrink)
  }
}
