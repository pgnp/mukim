id <-
function(nadata) { 
  m <- ncol(nadata)
  rmatrix <- is.na(nadata[,m:1])*1
  rmatrix <- unique(rmatrix,MARGIN=1)
  binsum <- crossprod(t(rmatrix), (2^(1:m - 1))) #one for each pattern
  rmatrix <- rmatrix[binsum>0,]
  binsum <- binsum[binsum>0]
  if (length(binsum)>1) {
    nrna <- rowSums(rmatrix) 
    rmatrix <- rmatrix[order(binsum),][order(nrna[order(binsum)]),m:1]
    ind <- apply(rmatrix,MARGIN=1,function(x) which(x==0))
    dep <- apply(rmatrix,MARGIN=1,function(x) which(x==1))
  } else {
    ind <- which(rmatrix[m:1]==0)
    dep <- which(rmatrix[m:1]==1)
  }
  list(ind=ind,dep=dep)
}
